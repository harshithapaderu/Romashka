 <?php
                   
     echo "LOGIN SUCCESS!";
                       
    echo "<p><a href=\"logout.php\"> LOGOUT </a></p>";
                    
      ?>