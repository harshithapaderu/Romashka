How to go to website:

domain name / URL : 	romashka.ictatjcub.com  OR  romashka.ictatjcub.com/Romashka/index.html

How to go to DB:

Phpmyadmin URL : romashka.ictatjcub.com/phpmyadmin

then login with :

database user: ictatjcu_romashk
database password: 123zxc
