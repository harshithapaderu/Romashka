<?php
session_start();
include_once('include/config.php');

if(isset($_POST['Fname'], $_POST['Sname'], $_POST['Pnum'], $_POST['email'], $_POST['zip'], $_POST['street'], $_POST['state'])) 
{
    //make the database connection
    $conn  = db_connect();

    $Fname = $conn -> real_escape_string($_POST['Fname']);
    $Sname = $conn -> real_escape_string($_POST['Sname']);
    $Pnum = $conn -> real_escape_string($_POST['Pnum']);
    $email = $conn -> real_escape_string($_POST['email']);
    $zip = $conn -> real_escape_string($_POST['zip']);
    $street = $conn -> real_escape_string($_POST['street']);
    $state = $conn -> real_escape_string($_POST['state']);
    //create an insert query
    $sql = "insert into registration (Fname, Sname, Pnum, email, zip, street, state)
			VALUES ('$Fname', '$Sname', '$Pnum', '$email', '$zip', '$street', '$state')";
   //execute the query
    if($conn -> query($sql))
    {
     echo "Registration Successful!";
     echo "You can now login via the username and password sent to your email";
     echo "<p><a href=\"login.php\"> LOGIN HERE!</a></p>";
    }

    $conn -> close();
}

else {
    die("Input error");
}